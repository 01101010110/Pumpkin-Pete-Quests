package com.poc.pumpkinpetequestlog;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import org.commonmark.node.Node;
import org.commonmark.parser.Parser;
import org.commonmark.renderer.html.HtmlRenderer;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private EditText searchBar;
    private Button btnSearch, btnNext;
    private boolean pageReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView   = findViewById(R.id.webView);
        searchBar = findViewById(R.id.searchBar);
        btnSearch = findViewById(R.id.btnSearch);
        btnNext   = findViewById(R.id.btnNext);

        // disable search until page loads
        searchBar.setEnabled(false);
        btnSearch.setEnabled(false);
        btnNext.setEnabled(false);

        // WebView setup
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                searchBar.setEnabled(true);
                btnSearch.setEnabled(true);
                btnNext.setEnabled(true);
            }
        });

        // fetch, split, render
        fetchAndRenderQuests();

        // common search action
        View.OnClickListener doSearch = v -> {
            if (!pageReady) return;
            String raw = searchBar.getText().toString().trim().toLowerCase();
            if (raw.isEmpty()) return;
            String q = raw.replace("'", "\\'");
            webView.evaluateJavascript(
                    "search('" + q + "')",
                    result -> {
                        if ("false".equals(result)) {
                            searchBar.setError("No results for \"" + raw + "\"");
                        }
                    }
            );
        };

        // on Enter / Done key
        searchBar.setOnEditorActionListener((TextView v, int actionId, KeyEvent event) -> {
            boolean isEnter = actionId == EditorInfo.IME_ACTION_SEARCH
                    || actionId == EditorInfo.IME_ACTION_DONE
                    || (event != null
                    && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                    && event.getAction() == KeyEvent.ACTION_DOWN);
            if (isEnter) {
                doSearch.onClick(null);
                return true;
            }
            return false;
        });

        btnSearch.setOnClickListener(doSearch);

        btnNext.setOnClickListener(v -> {
            if (!pageReady) return;
            webView.evaluateJavascript(
                    "nextMatch()",
                    result -> {
                        if ("false".equals(result)) {
                            // optional: toast no more matches
                        }
                    }
            );
        });
    }

    private void fetchAndRenderQuests() {
        new Thread(() -> {
            try {
                // 1) Download raw Markdown
                URL url = new URL(
                        "https://raw.githubusercontent.com/01101010110/Pumpkin-Pete-Quests/main/Quests.md");
                BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
                StringBuilder allMd = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    allMd.append(line).append("\n");
                }
                reader.close();

                // 2) Split on the horizontal-rule separators
                String[] blocks = allMd.toString().split("(?m)^---\\s*");

                // prepare CommonMark parser & renderer once
                Parser parser = Parser.builder().build();
                HtmlRenderer renderer = HtmlRenderer.builder()
                        .escapeHtml(false)
                        .build();

                // 3) Build one big HTML body
                StringBuilder body = new StringBuilder();
                ArrayList<String> ids = new ArrayList<>();

                for (String block : blocks) {
                    // find the title: line starting **Quest Name** then next non-blank
                    String title = null;
                    for (String l : block.split("\n")) {
                        if (l.trim().startsWith("**Quest Name**")) {
                            continue;
                        }
                        if (title == null && !l.trim().isEmpty()) {
                            title = l.trim();
                            break;
                        }
                    }
                    if (title == null) continue;

                    String safe = title.toLowerCase().replaceAll("[^a-z0-9]", "");
                    ids.add(safe);

                    Node doc = parser.parse(block);
                    String htmlBlock = renderer.render(doc);

                    body.append("<div id=\"").append(safe).append("\" ")
                            .append("style=\"margin-bottom:40px;\">")
                            .append(htmlBlock)
                            .append("</div>\n");
                }

                // 4) Wrap with CSS + new JS helper functions
                String fullHtml = "<html><head><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
                        + "<style>"
                        + "body{background:#121212;color:#E0E0E0;padding:12px;font-family:sans-serif;}"
                        + "h1,h2,strong{color:#BB86FC;}"
                        + "img{max-width:100%;height:auto;margin:8px 0;}"
                        + "</style>"
                        + "<script>"
                        + "  var matches = [];"
                        + "  var current = 0;"
                        + ""
                        + "  function search(q) {"
                        + "    matches = [];"
                        + "    current = 0;"
                        + "    var divs = document.querySelectorAll('div[id]');"
                        + "    divs.forEach(function(div) {"
                        + "      if (div.innerText.toLowerCase().includes(q)) {"
                        + "        matches.push(div);"
                        + "      }"
                        + "    });"
                        + "    if (matches.length > 0) {"
                        + "      matches[0].scrollIntoView({behavior:'smooth'});"
                        + "      return true;"
                        + "    }"
                        + "    return false;"
                        + "  }"
                        + ""
                        + "  function nextMatch() {"
                        + "    if (matches.length <= 1) return false;"
                        + "    current = (current + 1) % matches.length;"
                        + "    matches[current].scrollIntoView({behavior:'smooth'});"
                        + "    return true;"
                        + "  }"
                        + "</script>"
                        + "</head><body>"
                        + body.toString()
                        + "</body></html>";

                // 5) Load into WebView
                runOnUiThread(() ->
                        webView.loadDataWithBaseURL("file://", fullHtml, "text/html", "UTF-8", null)
                );

            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() ->
                        webView.loadData("Failed to load quests.", "text/html", "UTF-8")
                );
            }
        }).start();
    }
}

